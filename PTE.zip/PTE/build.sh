#!/bin/bash

echo "Assembling..."
as main.s -o main.o --64 -g
as get_string_length.s -o get_string_length.o --64 -g
as print_msg.s -o print_msg.o --64 -g
as read_file.s -o read_file.o --64 -g
echo "Linking"
ld main.o get_string_length.o print_msg.o read_file.o -o program.elf -e main  -nostdlib -static
echo "Clearing..."
rm main.o get_string_length.o print_msg.o read_file.o
