#!/bin/bash

echo "Assembling..."
as main.s -o main.o --32
echo "Linking"
ld main.o -m elf_i386 -o program.elf --oformat elf32-i386 -nostdlib -static
echo "Clearing..."
rm main.o
